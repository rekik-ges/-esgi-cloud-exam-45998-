module.exports = {
  content: ["./public/*.{html,js}","./views/*.twig"],
  theme: {
    extend: {},
  },
  plugins: [],
}
